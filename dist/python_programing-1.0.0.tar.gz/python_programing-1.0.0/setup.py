from distutils.core import setup

setup(
    name='python_programing',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://tokio_python.appspot.com',
    license='Free',
    author='tokio',
    author_email='',
    description='sample=package'
    )

#どう実行するか？
# python3 setup.py sdist
